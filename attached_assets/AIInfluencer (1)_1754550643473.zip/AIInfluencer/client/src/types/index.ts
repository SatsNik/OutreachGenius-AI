export interface User {
  id: string;
  email?: string;
  firstName?: string;
  lastName?: string;
  profileImageUrl?: string;
}

export interface Brand {
  id: string;
  userId: string;
  name: string;
  category: string;
  description?: string;
  targetAudience?: {
    ageRange: string;
    location: string;
    interests: string[];
    demographics: string;
  };
  brandTone?: string;
  campaignGoals?: string[];
  platformFocus?: string[];
  budgetRange?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Campaign {
  id: string;
  brandId: string;
  name: string;
  description?: string;
  status: string;
  targetFollowerRange?: string;
  targetPlatforms?: string[];
  targetLocation?: string;
  targetCategory?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Influencer {
  id: string;
  username: string;
  platform: string;
  platformId?: string;
  name?: string;
  email?: string;
  profileImageUrl?: string;
  bio?: string;
  followerCount?: number;
  engagementRate?: string;
  location?: string;
  category?: string;
  verified?: boolean;
  contactInfo?: {
    email?: string;
    website?: string;
    businessEmail?: string;
  };
  lastAnalyzed?: string;
  createdAt: string;
  updatedAt: string;
}

export interface BrandFitScore {
  id: string;
  brandId: string;
  influencerId: string;
  score: string;
  analysis?: {
    contentAlignment: number;
    audienceMatch: number;
    engagementQuality: number;
    brandSafety: number;
    reasons: string[];
  };
  createdAt: string;
}

export interface OutreachMessage {
  id: string;
  campaignId: string;
  influencerId: string;
  subject: string;
  content: string;
  personalizedContent?: string;
  status: string;
  sentAt?: string;
  openedAt?: string;
  repliedAt?: string;
  responseContent?: string;
  emailId?: string;
  createdAt: string;
  updatedAt: string;
}
