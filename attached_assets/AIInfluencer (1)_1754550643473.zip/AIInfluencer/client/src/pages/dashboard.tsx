import Header from "@/components/header";
import StatsOverview from "@/components/stats-overview";
import InfluencerDiscovery from "@/components/influencer-discovery";
import CampaignManagement from "@/components/campaign-management";
import BrandSetup from "@/components/brand-setup";
import AIInsights from "@/components/ai-insights";
import QuickActions from "@/components/quick-actions";

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-surface">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section with Gradient */}
        <div className="mb-8">
          <div className="bg-gradient-to-r from-primary to-blue-600 rounded-xl p-6 text-white mb-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold mb-2">Welcome to ICY AI Agent</h2>
                <p className="text-blue-100 mb-4">Your intelligent influencer outreach companion is ready to find perfect brand matches.</p>
                <div className="flex items-center space-x-4">
                  <button className="bg-white text-primary px-4 py-2 rounded-lg font-medium hover:bg-blue-50 transition-colors">
                    Complete Brand Setup
                  </button>
                  <button className="border border-white/30 text-white px-4 py-2 rounded-lg font-medium hover:bg-white/10 transition-colors">
                    Start Discovery
                  </button>
                </div>
              </div>
              <div className="hidden lg:block">
                <svg className="h-24 w-24 text-white/20" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M13 10V3L4 14h7v7l9-11h-7z"/>
                </svg>
              </div>
            </div>
          </div>

          <StatsOverview />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            <InfluencerDiscovery />
            <CampaignManagement />
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <BrandSetup />
            <AIInsights />
            <QuickActions />
          </div>
        </div>
      </div>
    </div>
  );
}
