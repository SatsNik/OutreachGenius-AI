import { MoreHorizontal, Calendar } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

interface CampaignCardProps {
  campaign: {
    id: string;
    name: string;
    description: string;
    status: string;
    stats: {
      sent: number;
      opened: number;
      replied: number;
      confirmed: number;
    };
    progress?: number;
    progressText?: string;
  };
}

export default function CampaignCard({ campaign }: CampaignCardProps) {
  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "active":
        return "bg-success/10 text-success";
      case "pending":
        return "bg-warning/10 text-warning";
      case "completed":
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-gray-100 text-gray-600";
    }
  };

  const progressPercentage = campaign.progress || 
    (campaign.stats.sent > 0 ? Math.round((campaign.stats.replied / campaign.stats.sent) * 100) : 0);

  return (
    <div className="border border-gray-200 rounded-lg p-4">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h4 className="font-semibold text-text-primary">{campaign.name}</h4>
          <p className="text-text-secondary text-sm">{campaign.description}</p>
        </div>
        <div className="flex items-center space-x-2">
          <Badge className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(campaign.status)}`}>
            {campaign.status.charAt(0).toUpperCase() + campaign.status.slice(1)}
          </Badge>
          <Button variant="ghost" size="sm">
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-4 gap-4 mb-3">
        <div>
          <p className="text-xs text-text-secondary">Sent</p>
          <p className="font-semibold text-text-primary">{campaign.stats.sent}</p>
        </div>
        <div>
          <p className="text-xs text-text-secondary">Opened</p>
          <p className="font-semibold text-text-primary">{campaign.stats.opened}</p>
        </div>
        <div>
          <p className="text-xs text-text-secondary">Replied</p>
          <p className="font-semibold text-text-primary">{campaign.stats.replied}</p>
        </div>
        <div>
          <p className="text-xs text-text-secondary">Confirmed</p>
          <p className="font-semibold text-text-primary">{campaign.stats.confirmed}</p>
        </div>
      </div>
      
      <div className="w-full bg-gray-200 rounded-full h-2">
        <div 
          className="bg-primary h-2 rounded-full transition-all duration-300"
          style={{ width: `${progressPercentage}%` }}
        ></div>
      </div>
      <p className="text-xs text-text-secondary mt-1">
        {campaign.progressText || `${progressPercentage}% response rate`}
      </p>
    </div>
  );
}
