import { useQuery } from "@tanstack/react-query";
import { Zap, Info, CheckCircle, AlertTriangle } from "lucide-react";

export default function AIInsights() {
  const { data: insightsData, isLoading } = useQuery({
    queryKey: ["/api/ai-insights"],
  });

  if (isLoading) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            <div className="h-16 bg-gray-200 rounded"></div>
            <div className="h-16 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  // Mock insights if API doesn't return data
  const mockInsights = [
    {
      type: "info" as const,
      title: "Optimal Posting Time",
      description: "Your target influencers are most active between 2-4 PM EST on weekdays.",
    },
    {
      type: "success" as const,
      title: "High-Performing Keywords",
      description: '"Sustainable", "clean beauty", and "eco-friendly" increase response rates by 34%.',
    },
    {
      type: "warning" as const,
      title: "Message Length",
      description: "Keep initial outreach under 150 words for 28% better response rates.",
    },
  ];

  const insights = (insightsData as any)?.insights || mockInsights;

  const getInsightIcon = (type: string) => {
    switch (type) {
      case "info":
        return Info;
      case "success":
        return CheckCircle;
      case "warning":
        return AlertTriangle;
      default:
        return Info;
    }
  };

  const getInsightStyles = (type: string) => {
    switch (type) {
      case "info":
        return {
          container: "bg-blue-50 border-blue-200",
          icon: "text-blue-600",
          title: "text-blue-900",
          description: "text-blue-700",
        };
      case "success":
        return {
          container: "bg-accent/10 border-accent/20",
          icon: "text-accent",
          title: "text-emerald-900",
          description: "text-emerald-700",
        };
      case "warning":
        return {
          container: "bg-warning/10 border-warning/20",
          icon: "text-warning",
          title: "text-amber-900",
          description: "text-amber-700",
        };
      default:
        return {
          container: "bg-gray-50 border-gray-200",
          icon: "text-gray-600",
          title: "text-gray-900",
          description: "text-gray-700",
        };
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center space-x-2">
          <Zap className="h-5 w-5 text-primary" />
          <h3 className="text-lg font-semibold text-text-primary">AI Insights</h3>
        </div>
        <p className="text-text-secondary text-sm mt-1">Powered by Gemini 2.0 Flash Lite</p>
      </div>
      <div className="p-6">
        <div className="space-y-4">
          {insights.map((insight: any, index: number) => {
            const Icon = getInsightIcon(insight.type);
            const styles = getInsightStyles(insight.type);
            
            return (
              <div key={index} className={`${styles.container} border rounded-lg p-4`}>
                <div className="flex items-start space-x-3">
                  <Icon className={`h-5 w-5 ${styles.icon} mt-0.5`} />
                  <div>
                    <h4 className={`font-medium ${styles.title}`}>{insight.title}</h4>
                    <p className={`${styles.description} text-sm mt-1`}>{insight.description}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
