import { useState } from "react";
import { CheckCircle, XCircle, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function BrandSetup() {
  const [setupItems] = useState([
    { name: "Product Details", completed: true },
    { name: "Target Audience", completed: true },
    { name: "Brand Tone", completed: false },
    { name: "Campaign Goals", completed: false },
  ]);

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200">
      <div className="p-6 border-b border-gray-200">
        <h3 className="text-lg font-semibold text-text-primary">Brand Setup</h3>
        <p className="text-text-secondary text-sm mt-1">Configure your brand for better matches</p>
      </div>
      <div className="p-6">
        <div className="space-y-4">
          {setupItems.map((item, index) => (
            <div key={index} className="flex items-center justify-between">
              <span className="text-sm text-text-primary">{item.name}</span>
              {item.completed ? (
                <CheckCircle className="h-5 w-5 text-success" />
              ) : (
                <Plus className="h-5 w-5 text-text-secondary" />
              )}
            </div>
          ))}
        </div>
        <Button className="w-full mt-4 bg-primary text-white py-2 px-4 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors">
          Complete Setup
        </Button>
      </div>
    </div>
  );
}
