import { useQuery } from "@tanstack/react-query";
import { TrendingUp, MessageSquare, Users, Heart } from "lucide-react";

export default function StatsOverview() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 animate-pulse">
            <div className="h-4 bg-gray-200 rounded mb-2"></div>
            <div className="h-8 bg-gray-200 rounded mb-2"></div>
            <div className="h-3 bg-gray-200 rounded"></div>
          </div>
        ))}
      </div>
    );
  }

  const statCards = [
    {
      title: "Active Campaigns",
      value: (stats as any)?.activeCampaigns || 0,
      change: "+12%",
      changeText: "from last month",
      icon: TrendingUp,
      iconBg: "bg-primary/10",
      iconColor: "text-primary",
    },
    {
      title: "Messages Sent",
      value: (stats as any)?.messagesSent || 0,
      change: "+28%",
      changeText: "response rate",
      icon: MessageSquare,
      iconBg: "bg-accent/10",
      iconColor: "text-accent",
    },
    {
      title: "Influencers Found",
      value: (stats as any)?.influencersFound || 0,
      change: "92%",
      changeText: "brand fit score",
      icon: Users,
      iconBg: "bg-warning/10",
      iconColor: "text-warning",
    },
    {
      title: "Collaborations",
      value: (stats as any)?.collaborations || 0,
      change: "+5",
      changeText: "this week",
      icon: Heart,
      iconBg: "bg-purple-100",
      iconColor: "text-purple-600",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
      {statCards.map((stat, index) => {
        const Icon = stat.icon;
        return (
          <div key={index} className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-text-secondary text-sm font-medium">{stat.title}</p>
                <p className="text-2xl font-bold text-text-primary">{stat.value.toLocaleString()}</p>
              </div>
              <div className={`p-3 ${stat.iconBg} rounded-lg`}>
                <Icon className={`h-6 w-6 ${stat.iconColor}`} />
              </div>
            </div>
            <div className="flex items-center mt-2">
              <span className="text-success text-sm font-medium">{stat.change}</span>
              <span className="text-text-secondary text-sm ml-1">{stat.changeText}</span>
            </div>
          </div>
        );
      })}
    </div>
  );
}
