import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { ExternalLink, MapPin, Users, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/api";
import type { Influencer, BrandFitScore } from "@/types";

interface InfluencerCardProps {
  influencer: Influencer;
  brandId?: string;
}

export default function InfluencerCard({ influencer, brandId = "demo-brand-id" }: InfluencerCardProps) {
  const { toast } = useToast();
  const [brandFitScore, setBrandFitScore] = useState<BrandFitScore | null>(null);

  const analyzeMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/analyze-brand-fit", {
        brandId,
        influencerId: influencer.id,
      });
      return response.json();
    },
    onSuccess: (data) => {
      setBrandFitScore(data);
    },
    onError: () => {
      toast({
        title: "Analysis Failed",
        description: "Could not analyze brand fit. Please try again.",
        variant: "destructive",
      });
    },
  });

  const outreachMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/generate-outreach", {
        brandId,
        influencerId: influencer.id,
      });
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Outreach Generated",
        description: "Personalized message has been created.",
      });
      // You could open a modal here to show the generated message
      console.log("Generated outreach:", data);
    },
    onError: () => {
      toast({
        title: "Generation Failed",
        description: "Could not generate outreach message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const getBrandFitColor = (score: number) => {
    if (score >= 90) return "text-success bg-success/10";
    if (score >= 80) return "text-warning bg-warning/10";
    return "text-error bg-error/10";
  };

  const formatFollowerCount = (count: number) => {
    if (count >= 1000000) return `${(count / 1000000).toFixed(1)}M`;
    if (count >= 1000) return `${(count / 1000).toFixed(1)}K`;
    return count.toString();
  };

  return (
    <div className="border border-gray-200 rounded-lg p-4">
      <div className="flex items-start space-x-4">
        <div className="w-16 h-16 rounded-xl bg-gray-200 flex items-center justify-center overflow-hidden">
          {influencer.profileImageUrl ? (
            <img
              src={influencer.profileImageUrl}
              alt={`${influencer.username} profile`}
              className="w-full h-full object-cover"
            />
          ) : (
            <Users className="h-8 w-8 text-gray-400" />
          )}
        </div>
        
        <div className="flex-1">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-semibold text-text-primary">@{influencer.username}</h4>
              <p className="text-text-secondary text-sm">{influencer.category || "Content Creator"}</p>
            </div>
            <div className="flex items-center space-x-2">
              {brandFitScore && (
                <Badge className={`px-2 py-1 rounded-full text-xs font-medium ${getBrandFitColor(parseInt(brandFitScore.score))}`}>
                  {brandFitScore.score}% Brand Fit
                </Badge>
              )}
              <button className="text-primary hover:text-blue-700">
                <ExternalLink className="h-5 w-5" />
              </button>
            </div>
          </div>
          
          <div className="grid grid-cols-3 gap-4 mt-3">
            <div className="text-center">
              <p className="font-semibold text-text-primary">
                {influencer.followerCount ? formatFollowerCount(influencer.followerCount) : "N/A"}
              </p>
              <p className="text-xs text-text-secondary">Followers</p>
            </div>
            <div className="text-center">
              <p className="font-semibold text-text-primary">
                {influencer.engagementRate ? `${parseFloat(influencer.engagementRate).toFixed(1)}%` : "N/A"}
              </p>
              <p className="text-xs text-text-secondary">Engagement</p>
            </div>
            <div className="text-center">
              <p className="font-semibold text-text-primary">{influencer.location || "Global"}</p>
              <p className="text-xs text-text-secondary">Location</p>
            </div>
          </div>
          
          <div className="flex items-center justify-between mt-4">
            <div className="flex items-center space-x-2">
              <Badge variant="secondary" className="text-xs">
                {influencer.platform === 'youtube' ? 'YouTube' : 'Instagram'}
              </Badge>
              {influencer.category && (
                <Badge variant="outline" className="text-xs">
                  {influencer.category}
                </Badge>
              )}
            </div>
            <div className="flex items-center space-x-2">
              {!brandFitScore && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => analyzeMutation.mutate()}
                  disabled={analyzeMutation.isPending}
                >
                  <TrendingUp className="h-4 w-4 mr-1" />
                  {analyzeMutation.isPending ? "Analyzing..." : "Analyze Fit"}
                </Button>
              )}
              <Button
                size="sm"
                onClick={() => outreachMutation.mutate()}
                disabled={outreachMutation.isPending}
                className="bg-primary text-white hover:bg-blue-700"
              >
                {outreachMutation.isPending ? "Generating..." : "Generate Outreach"}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
