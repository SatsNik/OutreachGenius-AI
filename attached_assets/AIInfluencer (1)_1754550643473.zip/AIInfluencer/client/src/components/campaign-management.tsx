import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Plus, MoreHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import CampaignCard from "@/components/campaign-card";
import type { Campaign } from "@/types";

export default function CampaignManagement() {
  const [selectedBrandId] = useState("demo-brand-id"); // In production, get from context/state

  const { data: campaigns, isLoading } = useQuery({
    queryKey: ["/api/campaigns", { brandId: selectedBrandId }],
    enabled: !!selectedBrandId,
  });

  if (isLoading) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-1/4"></div>
            <div className="h-20 bg-gray-200 rounded"></div>
            <div className="h-20 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  // Mock campaigns if API returns empty
  const mockCampaigns = [
    {
      id: "1",
      name: "Eco Skincare Launch",
      description: "Sustainable beauty product collaboration",
      status: "active",
      stats: { sent: 23, opened: 18, replied: 7, confirmed: 3 },
      progress: 78,
      progressText: "78% response rate",
    },
    {
      id: "2",
      name: "Summer Fashion Collection",
      description: "Lifestyle influencer partnerships",
      status: "pending",
      stats: { sent: 45, opened: 32, replied: 12, confirmed: 5 },
      progress: 71,
      progressText: "71% response rate",
    },
  ];

  const displayCampaigns = (campaigns as any) && (campaigns as any).length > 0 ? campaigns : mockCampaigns;

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-text-primary">Active Campaigns</h3>
            <p className="text-text-secondary text-sm mt-1">Monitor your outreach campaigns and responses</p>
          </div>
          <Button className="bg-primary text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors">
            <Plus className="h-4 w-4 mr-2" />
            New Campaign
          </Button>
        </div>
      </div>

      <div className="p-6">
        {(displayCampaigns as any).length > 0 ? (
          <div className="space-y-4">
            {(displayCampaigns as any).map((campaign: any) => (
              <CampaignCard key={campaign.id} campaign={campaign} />
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <Plus className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500 mb-4">No campaigns found</p>
            <Button className="bg-primary text-white">Create Your First Campaign</Button>
          </div>
        )}
      </div>
    </div>
  );
}
