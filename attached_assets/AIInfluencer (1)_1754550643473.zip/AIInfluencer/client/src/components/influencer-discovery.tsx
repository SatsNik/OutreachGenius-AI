import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Zap, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import InfluencerCard from "@/components/influencer-card";
import { apiRequest } from "@/lib/api";
import type { Influencer } from "@/types";

export default function InfluencerDiscovery() {
  const { toast } = useToast();
  const [searchForm, setSearchForm] = useState({
    category: "Beauty & Skincare",
    followerRange: "10K - 50K (Micro)",
    platforms: {
      instagram: true,
      youtube: false,
    },
    location: "",
  });

  const [discoveredInfluencers, setDiscoveredInfluencers] = useState<Influencer[]>([]);

  const discoveryMutation = useMutation({
    mutationFn: async () => {
      const platforms = [];
      if (searchForm.platforms.instagram) platforms.push("instagram");
      if (searchForm.platforms.youtube) platforms.push("youtube");

      const response = await apiRequest("POST", "/api/discover-influencers", {
        category: searchForm.category,
        platforms,
        followerRange: searchForm.followerRange,
        location: searchForm.location,
      });

      return response.json();
    },
    onSuccess: (data) => {
      setDiscoveredInfluencers(data);
      toast({
        title: "Discovery Complete",
        description: `Found ${data.length} influencers matching your criteria.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Discovery Failed",
        description: "Failed to discover influencers. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleDiscovery = () => {
    discoveryMutation.mutate();
  };

  const updatePlatform = (platform: "instagram" | "youtube", checked: boolean) => {
    setSearchForm(prev => ({
      ...prev,
      platforms: {
        ...prev.platforms,
        [platform]: checked,
      },
    }));
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-text-primary">AI Influencer Discovery</h3>
            <p className="text-text-secondary text-sm mt-1">Find perfect influencers with AI-powered matching</p>
          </div>
          <div className="flex items-center space-x-2">
            <div className="flex items-center space-x-1">
              <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
              <span className="text-sm text-success font-medium">AI Active</span>
            </div>
          </div>
        </div>
      </div>

      <div className="p-6">
        {/* Search Form */}
        <div className="space-y-4 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label className="block text-sm font-medium text-text-primary mb-2">Product Category</Label>
              <Select value={searchForm.category} onValueChange={(value) => setSearchForm(prev => ({ ...prev, category: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Beauty & Skincare">Beauty & Skincare</SelectItem>
                  <SelectItem value="Fashion & Lifestyle">Fashion & Lifestyle</SelectItem>
                  <SelectItem value="Fitness & Wellness">Fitness & Wellness</SelectItem>
                  <SelectItem value="Technology">Technology</SelectItem>
                  <SelectItem value="Food & Beverage">Food & Beverage</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="block text-sm font-medium text-text-primary mb-2">Follower Range</Label>
              <Select value={searchForm.followerRange} onValueChange={(value) => setSearchForm(prev => ({ ...prev, followerRange: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="10K - 50K (Micro)">10K - 50K (Micro)</SelectItem>
                  <SelectItem value="50K - 100K (Mid-tier)">50K - 100K (Mid-tier)</SelectItem>
                  <SelectItem value="100K - 500K (Macro)">100K - 500K (Macro)</SelectItem>
                  <SelectItem value="500K+ (Mega)">500K+ (Mega)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label className="block text-sm font-medium text-text-primary mb-2">Platform</Label>
              <div className="flex space-x-4">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="instagram"
                    checked={searchForm.platforms.instagram}
                    onCheckedChange={(checked) => updatePlatform("instagram", checked as boolean)}
                  />
                  <Label htmlFor="instagram" className="text-sm">Instagram</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="youtube"
                    checked={searchForm.platforms.youtube}
                    onCheckedChange={(checked) => updatePlatform("youtube", checked as boolean)}
                  />
                  <Label htmlFor="youtube" className="text-sm">YouTube</Label>
                </div>
              </div>
            </div>
            <div>
              <Label className="block text-sm font-medium text-text-primary mb-2">Location</Label>
              <Input
                type="text"
                placeholder="e.g., United States, Europe"
                value={searchForm.location}
                onChange={(e) => setSearchForm(prev => ({ ...prev, location: e.target.value }))}
              />
            </div>
          </div>
          <Button
            onClick={handleDiscovery}
            disabled={discoveryMutation.isPending}
            className="w-full bg-primary text-white py-3 px-4 rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2"
          >
            <Zap className="h-5 w-5" />
            <span>{discoveryMutation.isPending ? "Discovering..." : "Run AI Discovery"}</span>
          </Button>
        </div>

        {/* Discovery Results */}
        {discoveredInfluencers.length > 0 ? (
          <div className="space-y-4">
            <h4 className="font-semibold text-text-primary">Discovered Influencers</h4>
            {discoveredInfluencers.map((influencer) => (
              <InfluencerCard key={influencer.id} influencer={influencer} />
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <Search className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">Run AI Discovery to find influencers matching your criteria</p>
          </div>
        )}
      </div>
    </div>
  );
}
