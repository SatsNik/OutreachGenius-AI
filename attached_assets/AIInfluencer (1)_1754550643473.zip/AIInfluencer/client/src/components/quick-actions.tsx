import { MessageSquare, Download, Clock } from "lucide-react";

export default function QuickActions() {
  const actions = [
    {
      title: "Bulk Outreach",
      description: "Send to multiple influencers",
      icon: MessageSquare,
      onClick: () => console.log("Bulk outreach"),
    },
    {
      title: "Export Campaign",
      description: "Download performance report",
      icon: Download,
      onClick: () => console.log("Export campaign"),
    },
    {
      title: "Follow-up Reminders",
      description: "Automated scheduling",
      icon: Clock,
      onClick: () => console.log("Set reminders"),
    },
  ];

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200">
      <div className="p-6 border-b border-gray-200">
        <h3 className="text-lg font-semibold text-text-primary">Quick Actions</h3>
        <p className="text-text-secondary text-sm mt-1">Common tasks and shortcuts</p>
      </div>
      <div className="p-6 space-y-3">
        {actions.map((action, index) => {
          const Icon = action.icon;
          return (
            <button
              key={index}
              onClick={action.onClick}
              className="w-full text-left p-3 rounded-lg border border-gray-200 hover:border-primary hover:bg-blue-50 transition-colors"
            >
              <div className="flex items-center space-x-3">
                <Icon className="h-5 w-5 text-primary" />
                <div>
                  <p className="font-medium text-text-primary">{action.title}</p>
                  <p className="text-text-secondary text-xs">{action.description}</p>
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
