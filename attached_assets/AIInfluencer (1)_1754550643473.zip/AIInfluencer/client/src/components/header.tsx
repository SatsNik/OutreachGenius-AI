import { User } from "lucide-react";

export default function Header() {
  return (
    <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <svg className="h-8 w-8 text-primary mr-3" fill="currentColor" viewBox="0 0 24 24">
                <path d="M13 10V3L4 14h7v7l9-11h-7z"/>
              </svg>
              <h1 className="text-2xl font-bold text-secondary">ICY</h1>
              <span className="ml-2 text-sm bg-primary/10 text-primary px-2 py-1 rounded-full">AI Agent</span>
            </div>
          </div>

          <nav className="hidden md:flex space-x-8">
            <a href="#" className="text-primary border-b-2 border-primary px-1 pb-4 text-sm font-medium">Dashboard</a>
            <a href="#" className="text-text-secondary hover:text-text-primary px-1 pb-4 text-sm font-medium">Campaigns</a>
            <a href="#" className="text-text-secondary hover:text-text-primary px-1 pb-4 text-sm font-medium">Influencers</a>
            <a href="#" className="text-text-secondary hover:text-text-primary px-1 pb-4 text-sm font-medium">Analytics</a>
          </nav>

          <div className="flex items-center space-x-4">
            <button className="p-2 text-text-secondary hover:text-text-primary">
              <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 17h5l-5 5v-5zM9 7H4l5-5v5zM20 12h-5m5 0a9 9 0 11-18 0 9 9 0 0118 0z"/>
              </svg>
            </button>
            <div className="flex items-center space-x-3">
              <div className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center">
                <User className="h-5 w-5 text-gray-600" />
              </div>
              <span className="hidden md:block text-sm font-medium">Demo User</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
