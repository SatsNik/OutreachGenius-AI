import { sql } from "drizzle-orm";
import {
  pgTable,
  text,
  varchar,
  integer,
  decimal,
  boolean,
  timestamp,
  jsonb,
  index,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Users table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Brands table
export const brands = pgTable("brands", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  name: varchar("name").notNull(),
  category: varchar("category").notNull(),
  description: text("description"),
  targetAudience: jsonb("target_audience").$type<{
    ageRange: string;
    location: string;
    interests: string[];
    demographics: string;
  }>(),
  brandTone: varchar("brand_tone"),
  campaignGoals: text("campaign_goals").array(),
  platformFocus: text("platform_focus").array(),
  budgetRange: varchar("budget_range"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Campaigns table
export const campaigns = pgTable("campaigns", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  brandId: varchar("brand_id").notNull().references(() => brands.id),
  name: varchar("name").notNull(),
  description: text("description"),
  status: varchar("status").notNull().default("active"),
  targetFollowerRange: varchar("target_follower_range"),
  targetPlatforms: text("target_platforms").array(),
  targetLocation: varchar("target_location"),
  targetCategory: varchar("target_category"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Influencers table
export const influencers = pgTable("influencers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: varchar("username").notNull(),
  platform: varchar("platform").notNull(),
  platformId: varchar("platform_id").unique(),
  name: varchar("name"),
  email: varchar("email"),
  profileImageUrl: varchar("profile_image_url"),
  bio: text("bio"),
  followerCount: integer("follower_count"),
  engagementRate: decimal("engagement_rate", { precision: 5, scale: 2 }),
  location: varchar("location"),
  category: varchar("category"),
  verified: boolean("verified").default(false),
  contactInfo: jsonb("contact_info").$type<{
    email?: string;
    website?: string;
    businessEmail?: string;
  }>(),
  lastAnalyzed: timestamp("last_analyzed"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Brand fit scores table
export const brandFitScores = pgTable("brand_fit_scores", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  brandId: varchar("brand_id").notNull().references(() => brands.id),
  influencerId: varchar("influencer_id").notNull().references(() => influencers.id),
  score: decimal("score", { precision: 5, scale: 2 }).notNull(),
  analysis: jsonb("analysis").$type<{
    contentAlignment: number;
    audienceMatch: number;
    engagementQuality: number;
    brandSafety: number;
    reasons: string[];
  }>(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Outreach messages table
export const outreachMessages = pgTable("outreach_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  campaignId: varchar("campaign_id").notNull().references(() => campaigns.id),
  influencerId: varchar("influencer_id").notNull().references(() => influencers.id),
  subject: varchar("subject").notNull(),
  content: text("content").notNull(),
  personalizedContent: text("personalized_content"),
  status: varchar("status").notNull().default("draft"),
  sentAt: timestamp("sent_at"),
  openedAt: timestamp("opened_at"),
  repliedAt: timestamp("replied_at"),
  responseContent: text("response_content"),
  emailId: varchar("email_id"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  brands: many(brands),
}));

export const brandsRelations = relations(brands, ({ one, many }) => ({
  user: one(users, {
    fields: [brands.userId],
    references: [users.id],
  }),
  campaigns: many(campaigns),
  brandFitScores: many(brandFitScores),
}));

export const campaignsRelations = relations(campaigns, ({ one, many }) => ({
  brand: one(brands, {
    fields: [campaigns.brandId],
    references: [brands.id],
  }),
  outreachMessages: many(outreachMessages),
}));

export const influencersRelations = relations(influencers, ({ many }) => ({
  brandFitScores: many(brandFitScores),
  outreachMessages: many(outreachMessages),
}));

export const brandFitScoresRelations = relations(brandFitScores, ({ one }) => ({
  brand: one(brands, {
    fields: [brandFitScores.brandId],
    references: [brands.id],
  }),
  influencer: one(influencers, {
    fields: [brandFitScores.influencerId],
    references: [influencers.id],
  }),
}));

export const outreachMessagesRelations = relations(outreachMessages, ({ one }) => ({
  campaign: one(campaigns, {
    fields: [outreachMessages.campaignId],
    references: [campaigns.id],
  }),
  influencer: one(influencers, {
    fields: [outreachMessages.influencerId],
    references: [influencers.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertBrandSchema = createInsertSchema(brands).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCampaignSchema = createInsertSchema(campaigns).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertInfluencerSchema = createInsertSchema(influencers).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertBrandFitScoreSchema = createInsertSchema(brandFitScores).omit({
  id: true,
  createdAt: true,
});

export const insertOutreachMessageSchema = createInsertSchema(outreachMessages).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type UpsertUser = typeof users.$inferInsert;
export type Brand = typeof brands.$inferSelect;
export type InsertBrand = z.infer<typeof insertBrandSchema>;
export type Campaign = typeof campaigns.$inferSelect;
export type InsertCampaign = z.infer<typeof insertCampaignSchema>;
export type Influencer = typeof influencers.$inferSelect;
export type InsertInfluencer = z.infer<typeof insertInfluencerSchema>;
export type BrandFitScore = typeof brandFitScores.$inferSelect;
export type InsertBrandFitScore = z.infer<typeof insertBrandFitScoreSchema>;
export type OutreachMessage = typeof outreachMessages.$inferSelect;
export type InsertOutreachMessage = z.infer<typeof insertOutreachMessageSchema>;
