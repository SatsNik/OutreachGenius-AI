interface InstagramBasicProfile {
  id: string;
  username: string;
  account_type: string;
  media_count: number;
}

interface InstagramMedia {
  id: string;
  caption?: string;
  media_type: string;
  media_url?: string;
  permalink: string;
  timestamp: string;
}

interface YouTubeChannel {
  id: string;
  snippet: {
    title: string;
    description: string;
    thumbnails: {
      default: { url: string };
    };
    country?: string;
  };
  statistics: {
    subscriberCount: string;
    videoCount: string;
    viewCount: string;
  };
}

interface DiscoveredInfluencer {
  username: string;
  platform: 'instagram' | 'youtube';
  platformId: string;
  name?: string;
  profileImageUrl?: string;
  bio?: string;
  followerCount?: number;
  location?: string;
  category?: string;
  engagementRate?: number;
  verified?: boolean;
  recentPosts?: string[];
  contactInfo?: {
    email?: string;
    website?: string;
    businessEmail?: string;
  };
}

export async function searchInstagramInfluencers(
  hashtag: string,
  category?: string,
  location?: string
): Promise<DiscoveredInfluencer[]> {
  try {
    // Note: Instagram Basic Display API has limitations for discovery
    // In a real implementation, you'd need Instagram Graph API with business permissions
    // For now, we'll return a structured response that would come from the API
    
    if (!process.env.INSTAGRAM_ACCESS_TOKEN) {
      console.warn("Instagram API not configured - returning empty results");
      return [];
    }

    // This would be the actual API call:
    // const response = await fetch(`https://graph.instagram.com/v19.0/ig_hashtag_search?user_id=${userId}&q=${hashtag}&access_token=${accessToken}`);
    
    // For demo purposes, returning empty array since we can't make real discovery calls
    // without proper Instagram Business API permissions
    return [];
  } catch (error) {
    console.error("Error searching Instagram influencers:", error);
    return [];
  }
}

export async function searchYouTubeInfluencers(
  query: string,
  category?: string,
  location?: string,
  minSubscribers?: number,
  maxSubscribers?: number
): Promise<DiscoveredInfluencer[]> {
  try {
    const apiKey = process.env.YOUTUBE_API_KEY;
    if (!apiKey) {
      console.warn("YouTube API key not configured - returning empty results");
      return [];
    }

    // Search for channels
    const searchUrl = new URL('https://www.googleapis.com/youtube/v3/search');
    searchUrl.searchParams.set('part', 'snippet');
    searchUrl.searchParams.set('type', 'channel');
    searchUrl.searchParams.set('q', query);
    searchUrl.searchParams.set('maxResults', '20');
    searchUrl.searchParams.set('key', apiKey);

    if (location) {
      searchUrl.searchParams.set('regionCode', location);
    }

    const searchResponse = await fetch(searchUrl.toString());
    if (!searchResponse.ok) {
      const errorText = await searchResponse.text();
      console.error(`YouTube API Error: ${searchResponse.status} ${searchResponse.statusText}`, errorText);
      throw new Error(`YouTube search failed: ${searchResponse.statusText} - ${errorText}`);
    }

    const searchData = await searchResponse.json();
    const channelIds = searchData.items?.map((item: any) => item.snippet.channelId) || [];

    if (channelIds.length === 0) {
      return [];
    }

    // Get detailed channel information
    const channelsUrl = new URL('https://www.googleapis.com/youtube/v3/channels');
    channelsUrl.searchParams.set('part', 'snippet,statistics');
    channelsUrl.searchParams.set('id', channelIds.join(','));
    channelsUrl.searchParams.set('key', apiKey);

    const channelsResponse = await fetch(channelsUrl.toString());
    if (!channelsResponse.ok) {
      throw new Error(`YouTube channels API failed: ${channelsResponse.statusText}`);
    }

    const channelsData = await channelsResponse.json();
    const influences: DiscoveredInfluencer[] = [];

    for (const channel of channelsData.items || []) {
      const subscriberCount = parseInt(channel.statistics.subscriberCount || '0');
      
      // Filter by subscriber count if specified
      if (minSubscribers && subscriberCount < minSubscribers) continue;
      if (maxSubscribers && subscriberCount > maxSubscribers) continue;

      // Extract business email from description if available
      const description = channel.snippet.description || '';
      const emailMatch = description.match(/[\w.-]+@[\w.-]+\.\w+/);
      
      influences.push({
        username: channel.snippet.title,
        platform: 'youtube',
        platformId: channel.id,
        name: channel.snippet.title,
        profileImageUrl: channel.snippet.thumbnails?.default?.url,
        bio: channel.snippet.description,
        followerCount: subscriberCount,
        location: channel.snippet.country,
        category: category || 'General',
        verified: false, // YouTube API doesn't provide verification status in basic response
        contactInfo: {
          email: emailMatch ? emailMatch[0] : undefined,
        },
      });
    }

    return influences;
  } catch (error) {
    console.error("Error searching YouTube influencers:", error);
    return [];
  }
}

export async function getInfluencerRecentPosts(
  platform: 'instagram' | 'youtube',
  platformId: string,
  count: number = 5
): Promise<string[]> {
  try {
    if (platform === 'instagram') {
      if (!process.env.INSTAGRAM_ACCESS_TOKEN) {
        return [];
      }

      // This would require Instagram Graph API with proper permissions
      // const response = await fetch(`https://graph.instagram.com/v19.0/${platformId}/media?fields=caption&limit=${count}&access_token=${process.env.INSTAGRAM_ACCESS_TOKEN}`);
      
      return [];
    } else if (platform === 'youtube') {
      const apiKey = process.env.YOUTUBE_API_KEY;
      if (!apiKey) {
        return [];
      }

      // Get recent videos from the channel
      const searchUrl = new URL('https://www.googleapis.com/youtube/v3/search');
      searchUrl.searchParams.set('part', 'snippet');
      searchUrl.searchParams.set('channelId', platformId);
      searchUrl.searchParams.set('type', 'video');
      searchUrl.searchParams.set('order', 'date');
      searchUrl.searchParams.set('maxResults', count.toString());
      searchUrl.searchParams.set('key', apiKey);

      const response = await fetch(searchUrl.toString());
      if (!response.ok) {
        throw new Error(`YouTube videos API failed: ${response.statusText}`);
      }

      const data = await response.json();
      return data.items?.map((item: any) => item.snippet.title) || [];
    }

    return [];
  } catch (error) {
    console.error("Error getting influencer recent posts:", error);
    return [];
  }
}

// Demo influencers for testing while API issues are resolved
const getDemoInfluencers = (category: string): DiscoveredInfluencer[] => {
  const allDemoInfluencers: DiscoveredInfluencer[] = [
    {
      username: "TechReviewGuru",
      platform: "youtube",
      platformId: "UCTechReviewGuru",
      name: "Tech Review Guru",
      followerCount: 85000,
      engagementRate: 4.2,
      profileImageUrl: "https://via.placeholder.com/150/3B82F6/FFFFFF?text=TR",
      bio: "Tech reviews, tutorials, and gadget unboxings. Helping you make informed tech decisions.",
      location: "San Francisco, CA",
      category: "tech",
      verified: true,
      recentPosts: [
        "Latest iPhone 15 Pro review is live! Check out the new features.",
        "Comparing the best laptops for 2024 - which one should you buy?"
      ],
      contactInfo: {
        email: "business@techreviewguru.com"
      }
    },
    {
      username: "CodeWithAlex",
      platform: "youtube",
      platformId: "UCCodeWithAlex", 
      name: "Alex Chen",
      followerCount: 156000,
      engagementRate: 5.1,
      profileImageUrl: "https://via.placeholder.com/150/10B981/FFFFFF?text=CA",
      bio: "Full-stack developer sharing coding tutorials and career advice.",
      location: "Austin, TX",
      category: "tech",
      verified: true,
      recentPosts: [
        "React 18 features every developer should know",
        "Building a REST API with Node.js and Express"
      ],
      contactInfo: {
        email: "collab@codewithalex.dev"
      }
    },
    {
      username: "FitnessWithSarah",
      platform: "youtube",
      platformId: "UCFitnessWithSarah",
      name: "Sarah Johnson",
      followerCount: 125000,
      engagementRate: 5.8,
      profileImageUrl: "https://via.placeholder.com/150/EF4444/FFFFFF?text=FS",
      bio: "Certified personal trainer sharing workout routines and nutrition tips.",
      location: "Los Angeles, CA", 
      category: "fitness",
      verified: true,
      recentPosts: [
        "30-minute full body workout - no equipment needed!",
        "Meal prep Sunday: High protein recipes for the week"
      ],
      contactInfo: {
        email: "collaborate@fitnesswithsarah.com"
      }
    },
    {
      username: "HomeFitness",
      platform: "youtube",
      platformId: "UCHomeFitness",
      name: "Mike Rodriguez",
      followerCount: 94000,
      engagementRate: 6.2,
      profileImageUrl: "https://via.placeholder.com/150/F59E0B/FFFFFF?text=HF",
      bio: "Home workout specialist. Fitness for busy people.",
      location: "Miami, FL",
      category: "fitness", 
      verified: false,
      recentPosts: [
        "15-minute morning routine to energize your day",
        "Yoga for beginners - complete guide"
      ],
      contactInfo: {
        email: "partnerships@homefitness.com"
      }
    },
    {
      username: "TravelAdventurer",
      platform: "youtube",
      platformId: "UCTravelAdventurer",
      name: "Emma Davis",
      followerCount: 67000,
      engagementRate: 6.1,
      profileImageUrl: "https://via.placeholder.com/150/8B5CF6/FFFFFF?text=TA",
      bio: "Exploring hidden gems around the world. Budget travel tips and guides.",
      location: "New York, NY",
      category: "travel",
      verified: false,
      recentPosts: [
        "10 stunning destinations you can visit for under $1000",
        "Backpacking through Southeast Asia: Complete guide"
      ],
      contactInfo: {
        email: "hello@traveladventurer.com"
      }
    },
    {
      username: "FoodieFrenzy", 
      platform: "youtube",
      platformId: "UCFoodieFrenzy",
      name: "Maria Garcia",
      followerCount: 92000,
      engagementRate: 7.3,
      profileImageUrl: "https://via.placeholder.com/150/F97316/FFFFFF?text=FF",
      bio: "Food reviews, cooking tutorials, and restaurant discoveries.",
      location: "Chicago, IL",
      category: "food",
      verified: true,
      recentPosts: [
        "Making authentic Italian pasta from scratch",
        "Top 5 hidden gem restaurants in Chicago"
      ],
      contactInfo: {
        email: "partnerships@foodiefrenzy.com"
      }
    },
    {
      username: "BeautyByEmma",
      platform: "youtube",
      platformId: "UCBeautyByEmma",
      name: "Emma Wilson",
      followerCount: 210000,
      engagementRate: 8.1,
      profileImageUrl: "https://via.placeholder.com/150/EC4899/FFFFFF?text=BE",
      bio: "Makeup artist and beauty enthusiast. Tutorials and product reviews.",
      location: "Los Angeles, CA",
      category: "beauty",
      verified: true,
      recentPosts: [
        "Get ready with me: Natural glam look",
        "Testing viral TikTok makeup hacks"
      ],
      contactInfo: {
        email: "business@beautybyemma.com"
      }
    }
  ];

  if (category && category !== 'all') {
    return allDemoInfluencers.filter(inf => inf.category === category);
  }
  return allDemoInfluencers;
};

export async function discoverInfluencers(filters: {
  category: string;
  platform: string[];
  followerMin?: number;
  followerMax?: number;
  location?: string;
}): Promise<DiscoveredInfluencer[]> {
  const allInfluencers: DiscoveredInfluencer[] = [];

  try {
    // Try to get real data first
    if (filters.platform.includes('youtube')) {
      try {
        const youtubeQuery = `${filters.category}${filters.location ? ` ${filters.location}` : ''}`;
        const youtubeInfluencers = await searchYouTubeInfluencers(
          youtubeQuery,
          filters.category,
          filters.location,
          filters.followerMin,
          filters.followerMax
        );
        allInfluencers.push(...youtubeInfluencers);
      } catch (error) {
        console.log('YouTube API error, will use demo data:', error.message);
      }
    }

    if (filters.platform.includes('instagram')) {
      try {
        const instagramInfluencers = await searchInstagramInfluencers(
          filters.category,
          filters.category,
          filters.location
        );
        allInfluencers.push(...instagramInfluencers);
      } catch (error) {
        console.log('Instagram API error, using demo data:', error);
      }
    }

    // If no real data, use demo data
    if (allInfluencers.length === 0) {
      console.log('Using demo influencer data for testing');
      const demoInfluencers = getDemoInfluencers(filters.category);
      
      // Apply follower filters to demo data
      const filteredDemos = demoInfluencers.filter(inf => {
        const minMatch = !filters.followerMin || (inf.followerCount && inf.followerCount >= filters.followerMin);
        const maxMatch = !filters.followerMax || (inf.followerCount && inf.followerCount <= filters.followerMax);
        return minMatch && maxMatch;
      });
      
      allInfluencers.push(...filteredDemos);
    }

    // Remove duplicates based on username and platform
    const uniqueInfluencers = allInfluencers.filter((influencer, index, self) =>
      index === self.findIndex(i => i.username === influencer.username && i.platform === influencer.platform)
    );

    return uniqueInfluencers;
  } catch (error) {
    console.error("Error in influencer discovery:", error);
    // Return demo data as ultimate fallback
    return getDemoInfluencers(filters.category).slice(0, 5);
  }
}
