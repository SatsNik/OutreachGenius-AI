import { MailService } from '@sendgrid/mail';

if (!process.env.SENDGRID_API_KEY) {
  console.warn("SENDGRID_API_KEY environment variable not set - email functionality will be limited");
}

const mailService = new MailService();
if (process.env.SENDGRID_API_KEY) {
  mailService.setApiKey(process.env.SENDGRID_API_KEY);
}

interface EmailParams {
  to: string;
  from: string;
  subject: string;
  text?: string;
  html?: string;
  trackingSettings?: {
    clickTracking?: {
      enable: boolean;
    };
    openTracking?: {
      enable: boolean;
    };
  };
}

export async function sendOutreachEmail(params: EmailParams): Promise<{
  success: boolean;
  messageId?: string;
  error?: string;
}> {
  try {
    if (!process.env.SENDGRID_API_KEY) {
      return {
        success: false,
        error: "SendGrid API key not configured"
      };
    }

    const emailData = {
      to: params.to,
      from: params.from,
      subject: params.subject,
      text: params.text,
      html: params.html || params.text?.replace(/\n/g, '<br>'),
      trackingSettings: {
        clickTracking: {
          enable: true,
        },
        openTracking: {
          enable: true,
        },
        ...params.trackingSettings,
      },
    } as any;

    const response = await mailService.send(emailData);
    
    return {
      success: true,
      messageId: response[0]?.headers?.['x-message-id'] || 'unknown',
    };
  } catch (error: any) {
    console.error('SendGrid email error:', error);
    return {
      success: false,
      error: error.message || 'Failed to send email',
    };
  }
}

export async function sendBulkOutreachEmails(emails: EmailParams[]): Promise<{
  successful: number;
  failed: number;
  results: Array<{
    to: string;
    success: boolean;
    messageId?: string;
    error?: string;
  }>;
}> {
  const results = [];
  let successful = 0;
  let failed = 0;

  for (const email of emails) {
    const result = await sendOutreachEmail(email);
    results.push({
      to: email.to,
      ...result,
    });

    if (result.success) {
      successful++;
    } else {
      failed++;
    }

    // Add delay between emails to avoid rate limiting
    if (emails.length > 1) {
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  }

  return {
    successful,
    failed,
    results,
  };
}

export async function validateEmail(email: string): Promise<boolean> {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}
