import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ 
  apiKey: process.env.GEMINI_API_KEY || process.env.GEMINI_KEY || "AIzaSyDANqyMJgyxeog62KzpoZ5LRA4YRa6SoX8" 
});

export interface BrandFitAnalysis {
  score: number;
  contentAlignment: number;
  audienceMatch: number;
  engagementQuality: number;
  brandSafety: number;
  reasons: string[];
}

export async function analyzeBrandFit(
  brandInfo: {
    name: string;
    category: string;
    description?: string;
    targetAudience?: any;
    brandTone?: string;
  },
  influencerInfo: {
    username: string;
    bio?: string;
    category?: string;
    followerCount?: number;
    engagementRate?: number;
    recentPosts?: string[];
  }
): Promise<BrandFitAnalysis> {
  try {
    const systemPrompt = `You are an expert influencer marketing analyst. 
Analyze the brand fit between a brand and an influencer based on the provided information.
Consider content alignment, audience match, engagement quality, and brand safety.
Provide a comprehensive analysis with scores from 0-100 for each category and an overall score.
Respond with JSON in this exact format:
{
  "score": number (0-100),
  "contentAlignment": number (0-100),
  "audienceMatch": number (0-100), 
  "engagementQuality": number (0-100),
  "brandSafety": number (0-100),
  "reasons": [string array of 3-5 key reasons for the score]
}`;

    const analysisPrompt = `
Brand Information:
- Name: ${brandInfo.name}
- Category: ${brandInfo.category}
- Description: ${brandInfo.description || 'Not provided'}
- Target Audience: ${JSON.stringify(brandInfo.targetAudience || {})}
- Brand Tone: ${brandInfo.brandTone || 'Not specified'}

Influencer Information:
- Username: ${influencerInfo.username}
- Bio: ${influencerInfo.bio || 'Not available'}
- Category: ${influencerInfo.category || 'Not specified'}
- Followers: ${influencerInfo.followerCount || 'Unknown'}
- Engagement Rate: ${influencerInfo.engagementRate || 'Unknown'}%
- Recent Posts: ${influencerInfo.recentPosts?.join(', ') || 'Not available'}

Analyze the brand fit comprehensively.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.0-flash-lite-preview",
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            score: { type: "number" },
            contentAlignment: { type: "number" },
            audienceMatch: { type: "number" },
            engagementQuality: { type: "number" },
            brandSafety: { type: "number" },
            reasons: { type: "array", items: { type: "string" } },
          },
          required: ["score", "contentAlignment", "audienceMatch", "engagementQuality", "brandSafety", "reasons"],
        },
      },
      contents: analysisPrompt,
    });

    const rawJson = response.text;
    if (!rawJson) {
      throw new Error("Empty response from Gemini");
    }

    const analysis: BrandFitAnalysis = JSON.parse(rawJson);
    return analysis;
  } catch (error) {
    console.error("Error analyzing brand fit:", error);
    // Return fallback analysis
    return {
      score: 50,
      contentAlignment: 50,
      audienceMatch: 50,
      engagementQuality: 50,
      brandSafety: 50,
      reasons: ["Analysis unavailable due to service error"],
    };
  }
}

export async function generatePersonalizedOutreach(
  brandInfo: {
    name: string;
    category: string;
    description?: string;
    brandTone?: string;
  },
  influencerInfo: {
    username: string;
    name?: string;
    bio?: string;
    recentPosts?: string[];
  },
  campaignGoals?: string[]
): Promise<{
  subject: string;
  content: string;
}> {
  try {
    const systemPrompt = `You are an expert email copywriter specializing in influencer outreach.
Create personalized, compelling outreach emails that feel authentic and build genuine connections.
Keep the tone professional but friendly, and always reference specific details about the influencer.
The email should be under 150 words for better response rates.
Respond with JSON in this format:
{
  "subject": "string",
  "content": "string"
}`;

    const outreachPrompt = `
Brand Information:
- Name: ${brandInfo.name}
- Category: ${brandInfo.category}
- Description: ${brandInfo.description || 'Not provided'}
- Brand Tone: ${brandInfo.brandTone || 'Professional and friendly'}

Influencer Information:
- Username: @${influencerInfo.username}
- Name: ${influencerInfo.name || influencerInfo.username}
- Bio: ${influencerInfo.bio || 'Not available'}
- Recent Posts: ${influencerInfo.recentPosts?.join(', ') || 'Not available'}

Campaign Goals: ${campaignGoals?.join(', ') || 'Brand awareness and engagement'}

Create a personalized outreach email that references their content and explains the collaboration opportunity.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.0-flash-lite-preview",
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            subject: { type: "string" },
            content: { type: "string" },
          },
          required: ["subject", "content"],
        },
      },
      contents: outreachPrompt,
    });

    const rawJson = response.text;
    if (!rawJson) {
      throw new Error("Empty response from Gemini");
    }

    const outreach = JSON.parse(rawJson);
    return outreach;
  } catch (error) {
    console.error("Error generating outreach:", error);
    // Return fallback message with multiple template options
    const templates = [
      {
        subject: `Collaboration Opportunity with ${brandInfo.name}`,
        content: `Hi ${influencerInfo.name || influencerInfo.username},\n\nI hope this message finds you well! I've been following your content and am impressed by your authentic approach to ${brandInfo.category}.\n\nI'd love to explore a potential collaboration between you and ${brandInfo.name}. We think your audience would genuinely connect with our brand values.\n\nWould you be interested in learning more about this opportunity?\n\nBest regards,\n${brandInfo.name} Team`,
      },
      {
        subject: `Partnership Proposal - ${brandInfo.name}`,
        content: `Hello ${influencerInfo.name || influencerInfo.username},\n\nYour ${brandInfo.category} content really resonates with our brand mission at ${brandInfo.name}. We'd love to discuss a potential partnership that could benefit both your audience and our brand.\n\nWe're looking for authentic creators who share our values, and you seem like a perfect fit!\n\nInterested in learning more?\n\nWarm regards,\n${brandInfo.name} Partnership Team`,
      },
      {
        subject: `Let's Create Something Amazing Together!`,
        content: `Hey ${influencerInfo.name || influencerInfo.username}!\n\nBig fan of your work in the ${brandInfo.category} space. At ${brandInfo.name}, we're always looking to partner with creative minds like yours.\n\nWe have some exciting collaboration ideas that could showcase your talents while introducing our brand to your engaged audience.\n\nWould you be open to a quick chat about possibilities?\n\nCheers,\n${brandInfo.name} Creative Team`,
      }
    ];
    
    // Return a random template for variety
    const randomTemplate = templates[Math.floor(Math.random() * templates.length)];
    return randomTemplate;
  }
}

export async function generateAIInsights(
  campaignData: {
    totalSent: number;
    responseRate: number;
    topPerformingKeywords?: string[];
    averageOpenTime?: string;
  }
): Promise<{
  insights: Array<{
    type: "info" | "success" | "warning";
    title: string;
    description: string;
  }>;
}> {
  try {
    const systemPrompt = `You are an AI marketing analyst providing actionable insights for influencer campaigns.
Based on campaign performance data, generate 3-4 specific, actionable insights.
Each insight should be categorized as "info", "success", or "warning" and include a clear title and description.
Focus on practical recommendations that can improve campaign performance.
Respond with JSON in this format:
{
  "insights": [
    {
      "type": "info" | "success" | "warning",
      "title": "string",
      "description": "string"
    }
  ]
}`;

    const insightsPrompt = `
Campaign Performance Data:
- Messages Sent: ${campaignData.totalSent}
- Response Rate: ${campaignData.responseRate}%
- Top Keywords: ${campaignData.topPerformingKeywords?.join(', ') || 'Not available'}
- Average Open Time: ${campaignData.averageOpenTime || 'Not available'}

Generate actionable insights to improve campaign performance.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.0-flash-lite-preview",
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            insights: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  type: { type: "string", enum: ["info", "success", "warning"] },
                  title: { type: "string" },
                  description: { type: "string" },
                },
                required: ["type", "title", "description"],
              },
            },
          },
          required: ["insights"],
        },
      },
      contents: insightsPrompt,
    });

    const rawJson = response.text;
    if (!rawJson) {
      throw new Error("Empty response from Gemini");
    }

    return JSON.parse(rawJson);
  } catch (error) {
    console.error("Error generating insights:", error);
    // Return fallback insights
    return {
      insights: [
        {
          type: "info",
          title: "Optimal Posting Time",
          description: "Most influencers are active between 2-4 PM EST on weekdays."
        },
        {
          type: "success", 
          title: "Response Rate",
          description: `Your ${campaignData.responseRate}% response rate is performing well.`
        },
        {
          type: "warning",
          title: "Message Length",
          description: "Keep initial outreach under 150 words for better response rates."
        }
      ]
    };
  }
}
