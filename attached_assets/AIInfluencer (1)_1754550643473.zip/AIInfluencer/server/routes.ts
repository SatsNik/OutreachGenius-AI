import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertBrandSchema, insertCampaignSchema, insertOutreachMessageSchema } from "@shared/schema";
import { analyzeBrandFit, generatePersonalizedOutreach, generateAIInsights } from "./services/gemini";
import { sendOutreachEmail, sendBulkOutreachEmails } from "./services/sendgrid";
import { discoverInfluencers, getInfluencerRecentPosts } from "./services/influencerAPI";

export async function registerRoutes(app: Express): Promise<Server> {
  // API Routes

  // Dashboard stats
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      // For now, return mock stats. In production, calculate from actual data
      const stats = {
        activeCampaigns: 3,
        messagesSent: 247,
        influencersFound: 1234,
        collaborations: 18,
      };

      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // Brand management
  app.get("/api/brands", async (req, res) => {
    try {
      // For demo purposes, using a mock user ID
      const userId = "demo-user";
      const brands = await storage.getBrandsByUserId(userId);
      res.json(brands);
    } catch (error) {
      console.error("Error fetching brands:", error);
      res.status(500).json({ message: "Failed to fetch brands" });
    }
  });

  app.post("/api/brands", async (req, res) => {
    try {
      const brandData = insertBrandSchema.parse(req.body);
      brandData.userId = "demo-user"; // In production, get from authenticated user
      
      const brand = await storage.createBrand(brandData);
      res.json(brand);
    } catch (error) {
      console.error("Error creating brand:", error);
      res.status(500).json({ message: "Failed to create brand" });
    }
  });

  app.put("/api/brands/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      const brand = await storage.updateBrand(id, updates);
      res.json(brand);
    } catch (error) {
      console.error("Error updating brand:", error);
      res.status(500).json({ message: "Failed to update brand" });
    }
  });

  // Campaign management
  app.get("/api/campaigns", async (req, res) => {
    try {
      const { brandId } = req.query;
      if (!brandId) {
        return res.status(400).json({ message: "Brand ID is required" });
      }

      const campaigns = await storage.getCampaignsByBrandId(brandId as string);
      
      // Enhance campaigns with stats
      const campaignsWithStats = await Promise.all(
        campaigns.map(async (campaign) => {
          const stats = await storage.getCampaignStats(campaign.id);
          return {
            ...campaign,
            stats,
          };
        })
      );

      res.json(campaignsWithStats);
    } catch (error) {
      console.error("Error fetching campaigns:", error);
      res.status(500).json({ message: "Failed to fetch campaigns" });
    }
  });

  app.post("/api/campaigns", async (req, res) => {
    try {
      const campaignData = insertCampaignSchema.parse(req.body);
      const campaign = await storage.createCampaign(campaignData);
      res.json(campaign);
    } catch (error) {
      console.error("Error creating campaign:", error);
      res.status(500).json({ message: "Failed to create campaign" });
    }
  });

  // Influencer discovery
  app.post("/api/discover-influencers", async (req, res) => {
    try {
      const { category, platforms, followerRange, location } = req.body;
      
      // Parse follower range
      let followerMin, followerMax;
      if (followerRange) {
        const ranges: Record<string, [number, number]> = {
          "10K - 50K (Micro)": [10000, 50000],
          "50K - 100K (Mid-tier)": [50000, 100000],
          "100K - 500K (Macro)": [100000, 500000],
          "500K+ (Mega)": [500000, Number.MAX_SAFE_INTEGER],
        };
        [followerMin, followerMax] = ranges[followerRange] || [0, Number.MAX_SAFE_INTEGER];
      }

      const filters = {
        category: category || "general",
        platform: platforms || ["youtube"],
        followerMin,
        followerMax,
        location,
      };

      const discoveredInfluencers = await discoverInfluencers(filters);
      
      // Store discovered influencers in database
      const storedInfluencers = [];
      for (const influencerData of discoveredInfluencers) {
        try {
          // Check if influencer already exists
          let influencer = await storage.getInfluencerByPlatformId(influencerData.platformId);
          
          if (!influencer) {
            // Create new influencer
            influencer = await storage.createInfluencer({
              username: influencerData.username,
              platform: influencerData.platform,
              platformId: influencerData.platformId,
              name: influencerData.name,
              profileImageUrl: influencerData.profileImageUrl,
              bio: influencerData.bio,
              followerCount: influencerData.followerCount,
              location: influencerData.location,
              category: influencerData.category,
              engagementRate: influencerData.engagementRate?.toString(),
              verified: influencerData.verified,
              contactInfo: influencerData.contactInfo,
              lastAnalyzed: new Date(),
            });
          }
          
          storedInfluencers.push(influencer);
        } catch (error) {
          console.error("Error storing influencer:", error);
        }
      }

      res.json(storedInfluencers);
    } catch (error) {
      console.error("Error discovering influencers:", error);
      res.status(500).json({ message: "Failed to discover influencers" });
    }
  });

  // Brand fit analysis
  app.post("/api/analyze-brand-fit", async (req, res) => {
    try {
      const { brandId, influencerId } = req.body;
      
      if (!brandId || !influencerId) {
        return res.status(400).json({ message: "Brand ID and Influencer ID are required" });
      }

      // Check if analysis already exists
      let existingScore = await storage.getBrandFitScore(brandId, influencerId);
      if (existingScore) {
        return res.json(existingScore);
      }

      // Get brand and influencer data
      const brand = await storage.getBrand(brandId);
      const influencer = await storage.getInfluencer(influencerId);

      if (!brand || !influencer) {
        return res.status(404).json({ message: "Brand or influencer not found" });
      }

      // Get recent posts for analysis
      const recentPosts = await getInfluencerRecentPosts(
        influencer.platform as 'instagram' | 'youtube',
        influencer.platformId!,
        5
      );

      // Analyze brand fit using Gemini
      const analysis = await analyzeBrandFit(
        {
          name: brand.name,
          category: brand.category,
          description: brand.description || undefined,
          targetAudience: brand.targetAudience,
          brandTone: brand.brandTone || undefined,
        },
        {
          username: influencer.username,
          bio: influencer.bio || undefined,
          category: influencer.category || undefined,
          followerCount: influencer.followerCount || undefined,
          engagementRate: influencer.engagementRate ? parseFloat(influencer.engagementRate) : undefined,
          recentPosts,
        }
      );

      // Store the analysis
      const brandFitScore = await storage.createBrandFitScore({
        brandId,
        influencerId,
        score: analysis.score.toString(),
        analysis: {
          contentAlignment: analysis.contentAlignment,
          audienceMatch: analysis.audienceMatch,
          engagementQuality: analysis.engagementQuality,
          brandSafety: analysis.brandSafety,
          reasons: analysis.reasons,
        },
      });

      res.json(brandFitScore);
    } catch (error) {
      console.error("Error analyzing brand fit:", error);
      res.status(500).json({ message: "Failed to analyze brand fit" });
    }
  });

  // Get brand fit scores for a brand
  app.get("/api/brands/:brandId/fit-scores", async (req, res) => {
    try {
      const { brandId } = req.params;
      const scores = await storage.getBrandFitScoresByBrand(brandId);
      res.json(scores);
    } catch (error) {
      console.error("Error fetching brand fit scores:", error);
      res.status(500).json({ message: "Failed to fetch brand fit scores" });
    }
  });

  // Generate outreach message
  app.post("/api/generate-outreach", async (req, res) => {
    try {
      const { brandId, influencerId, campaignId, brandName, influencerName } = req.body;
      
      // Accept either IDs or names for flexible usage
      if (!brandId && !brandName) {
        return res.status(400).json({ message: "Either brand ID or brand name is required" });
      }
      
      // Allow generating outreach with minimal data if brand/influencer aren't in DB
      let brand = null;
      let influencer = null;
      
      // Try to get from database first
      if (brandId) {
        brand = await storage.getBrand(brandId);
      }
      if (influencerId) {
        influencer = await storage.getInfluencer(influencerId);
      }

      // Create fallback data if not found in database
      const brandInfo = {
        name: brand?.name || brandName || "Your Brand",
        category: brand?.category || "general",
        description: brand?.description || "Innovative company seeking partnerships",
        brandTone: brand?.brandTone || "professional and friendly",
      };

      const influencerInfo = {
        username: influencer?.username || influencerName || "content creator",
        name: influencer?.name || influencerName || undefined,
        bio: influencer?.bio || "Content creator",
        recentPosts: [],
      };

      // Get recent posts if influencer exists in database
      if (influencer && influencer.platformId) {
        try {
          const recentPosts = await getInfluencerRecentPosts(
            influencer.platform as 'instagram' | 'youtube',
            influencer.platformId,
            3
          );
          influencerInfo.recentPosts = recentPosts;
        } catch (error) {
          console.log("Could not fetch recent posts, continuing without them");
        }
      }

      // Generate personalized outreach
      const outreach = await generatePersonalizedOutreach(
        brandInfo,
        influencerInfo,
        brand?.campaignGoals || ["brand awareness", "engagement"]
      );

      // If campaignId and valid IDs are provided, save the message
      if (campaignId && influencerId && brand && influencer) {
        try {
          const messageData = insertOutreachMessageSchema.parse({
            campaignId,
            influencerId,
            subject: outreach.subject,
            content: outreach.content,
            personalizedContent: outreach.content,
            status: "draft",
          });

          const savedMessage = await storage.createOutreachMessage(messageData);
          res.json({
            ...outreach,
            messageId: savedMessage.id,
            saved: true,
          });
        } catch (saveError) {
          console.error("Error saving message:", saveError);
          res.json({
            ...outreach,
            saved: false,
            note: "Message generated but not saved to database",
          });
        }
      } else {
        res.json({
          ...outreach,
          saved: false,
          note: "Message generated successfully",
        });
      }
    } catch (error) {
      console.error("Error generating outreach:", error);
      
      // Always return a message even if everything fails
      const fallbackBrand = req.body.brandName || "Your Brand";
      const fallbackInfluencer = req.body.influencerName || "there";
      
      res.json({
        subject: `Partnership Opportunity with ${fallbackBrand}`,
        content: `Hi ${fallbackInfluencer},\n\nI hope this message finds you well! I've been following your content and am impressed by your authentic approach.\n\nI'd love to explore a potential collaboration between you and ${fallbackBrand}. We think your audience would genuinely connect with our brand values.\n\nWould you be interested in learning more about this opportunity?\n\nBest regards,\n${fallbackBrand} Team`,
        saved: false,
        note: "Fallback message generated due to system error",
      });
    }
  });

  // Create or update brand
  app.post("/api/brands", async (req, res) => {
    try {
      const { name, category, description, brandTone, campaignGoals } = req.body;
      
      if (!name) {
        return res.status(400).json({ message: "Brand name is required" });
      }

      const brandData = {
        userId: 'test-user', // For demo purposes
        name,
        category: category || 'general',
        description: description || '',
        brandTone: brandTone || 'professional',
        campaignGoals: campaignGoals || ['brand_awareness'],
      };

      const brand = await storage.createBrand(brandData);
      res.json(brand);
    } catch (error) {
      console.error("Error creating brand:", error);
      res.status(500).json({ message: "Failed to create brand" });
    }
  });

  // Get all brands
  app.get("/api/brands", async (req, res) => {
    try {
      const brands = await storage.getAllBrands();
      res.json(brands);
    } catch (error) {
      console.error("Error fetching brands:", error);
      res.status(500).json({ message: "Failed to fetch brands" });
    }
  });

  // Generate multiple outreach templates
  app.post("/api/generate-outreach-templates", async (req, res) => {
    try {
      const { brandId, influencerId, brandName, influencerName } = req.body;
      
      // Accept either IDs or names for flexible usage
      if (!brandId && !brandName) {
        return res.status(400).json({ message: "Either brand ID or brand name is required" });
      }

      // Try to get from database first
      let brand = null;
      let influencer = null;
      
      if (brandId) {
        brand = await storage.getBrand(brandId);
      }
      if (influencerId) {
        influencer = await storage.getInfluencer(influencerId);
      }

      // Create fallback data if not found in database
      const baseBrandInfo = {
        name: brand?.name || brandName || "Your Brand",
        category: brand?.category || "general",
        description: brand?.description || "Innovative company seeking partnerships",
      };

      const baseInfluencerInfo = {
        username: influencer?.username || influencerName || "content creator",
        name: influencer?.name || influencerName || undefined,
        bio: influencer?.bio || "Content creator",
        recentPosts: [],
      };

      // Generate 3 different outreach templates
      const templates = [];
      const tones = ['professional', 'friendly', 'creative'];
      
      for (const tone of tones) {
        try {
          const brandInfo = {
            ...baseBrandInfo,
            brandTone: tone,
          };
          
          const influencerInfo = {
            ...baseInfluencerInfo,
          };

          const outreach = await generatePersonalizedOutreach(
            brandInfo,
            influencerInfo,
            brand?.campaignGoals || ["brand awareness", "engagement"]
          );

          templates.push({
            tone,
            subject: outreach.subject,
            content: outreach.content,
          });
        } catch (error) {
          console.error(`Error generating ${tone} template:`, error);
          // Add fallback template for this tone
          templates.push({
            tone,
            subject: `${tone === 'creative' ? 'Let\'s Create Magic!' : tone === 'friendly' ? 'Partnership Opportunity' : 'Collaboration Proposal'} - ${brand.name}`,
            content: `Hi ${influencer.name || influencer.username},\n\nWe'd love to explore a ${tone} partnership with ${brand.name}. Your ${brand.category} content aligns perfectly with our brand values.\n\nInterested in learning more?\n\nBest regards,\n${brand.name} Team`,
          });
        }
      }

      res.json({ templates });
    } catch (error) {
      console.error("Error generating outreach templates:", error);
      res.status(500).json({ message: "Failed to generate outreach templates" });
    }
  });

  // Send outreach email
  app.post("/api/send-outreach", async (req, res) => {
    try {
      const { messageId } = req.body;
      
      if (!messageId) {
        return res.status(400).json({ message: "Message ID is required" });
      }

      // Get message and related data
      const messages = await storage.getMessagesByCampaign(""); // We'll need to modify this
      const message = messages.find(m => m.id === messageId);
      
      if (!message) {
        return res.status(404).json({ message: "Message not found" });
      }

      const influencer = message.influencer;
      const campaign = await storage.getCampaign(message.campaignId);
      
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }

      const brand = await storage.getBrand(campaign.brandId);
      if (!brand) {
        return res.status(404).json({ message: "Brand not found" });
      }

      // Check if influencer has contact email
      const email = influencer.contactInfo?.email || influencer.email;
      if (!email) {
        return res.status(400).json({ message: "Influencer email not available" });
      }

      // Send email
      const emailResult = await sendOutreachEmail({
        to: email,
        from: `${brand.name} <noreply@example.com>`, // Use your verified sender
        subject: message.subject,
        text: message.personalizedContent || message.content,
      });

      if (emailResult.success) {
        // Update message status
        await storage.updateOutreachMessage(messageId, {
          status: "sent",
          sentAt: new Date(),
          emailId: emailResult.messageId,
        });

        res.json({ success: true, messageId: emailResult.messageId });
      } else {
        res.status(500).json({ success: false, error: emailResult.error });
      }
    } catch (error) {
      console.error("Error sending outreach:", error);
      res.status(500).json({ message: "Failed to send outreach email" });
    }
  });

  // Get campaign messages
  app.get("/api/campaigns/:campaignId/messages", async (req, res) => {
    try {
      const { campaignId } = req.params;
      const messages = await storage.getMessagesByCampaign(campaignId);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching campaign messages:", error);
      res.status(500).json({ message: "Failed to fetch campaign messages" });
    }
  });

  // Get AI insights
  app.get("/api/ai-insights", async (req, res) => {
    try {
      // Calculate insights from campaign data
      const insights = await generateAIInsights({
        totalSent: 247,
        responseRate: 28,
        topPerformingKeywords: ["sustainable", "clean beauty", "eco-friendly"],
        averageOpenTime: "2-4 PM EST",
      });

      res.json(insights);
    } catch (error) {
      console.error("Error generating AI insights:", error);
      res.status(500).json({ message: "Failed to generate AI insights" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
