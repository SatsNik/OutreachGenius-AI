import {
  users,
  brands,
  campaigns,
  influencers,
  brandFitScores,
  outreachMessages,
  type User,
  type UpsertUser,
  type Brand,
  type InsertBrand,
  type Campaign,
  type InsertCampaign,
  type Influencer,
  type InsertInfluencer,
  type BrandFitScore,
  type InsertBrandFitScore,
  type OutreachMessage,
  type InsertOutreachMessage,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql, ilike } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Brand operations
  getBrandsByUserId(userId: string): Promise<Brand[]>;
  getAllBrands(): Promise<Brand[]>;
  getBrand(id: string): Promise<Brand | undefined>;
  createBrand(brand: InsertBrand): Promise<Brand>;
  updateBrand(id: string, brand: Partial<InsertBrand>): Promise<Brand>;

  // Campaign operations
  getCampaignsByBrandId(brandId: string): Promise<Campaign[]>;
  getCampaign(id: string): Promise<Campaign | undefined>;
  createCampaign(campaign: InsertCampaign): Promise<Campaign>;
  updateCampaign(id: string, campaign: Partial<InsertCampaign>): Promise<Campaign>;

  // Influencer operations
  searchInfluencers(filters: {
    category?: string;
    platform?: string;
    minFollowers?: number;
    maxFollowers?: number;
    location?: string;
  }): Promise<Influencer[]>;
  getInfluencer(id: string): Promise<Influencer | undefined>;
  getInfluencerByPlatformId(platformId: string): Promise<Influencer | undefined>;
  createInfluencer(influencer: InsertInfluencer): Promise<Influencer>;
  updateInfluencer(id: string, influencer: Partial<InsertInfluencer>): Promise<Influencer>;

  // Brand fit score operations
  getBrandFitScore(brandId: string, influencerId: string): Promise<BrandFitScore | undefined>;
  createBrandFitScore(score: InsertBrandFitScore): Promise<BrandFitScore>;
  getBrandFitScoresByBrand(brandId: string): Promise<(BrandFitScore & { influencer: Influencer })[]>;

  // Outreach message operations
  getMessagesByCampaign(campaignId: string): Promise<(OutreachMessage & { influencer: Influencer })[]>;
  createOutreachMessage(message: InsertOutreachMessage): Promise<OutreachMessage>;
  updateOutreachMessage(id: string, message: Partial<InsertOutreachMessage>): Promise<OutreachMessage>;
  getCampaignStats(campaignId: string): Promise<{
    sent: number;
    opened: number;
    replied: number;
    confirmed: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Brand operations
  async getBrandsByUserId(userId: string): Promise<Brand[]> {
    return await db
      .select()
      .from(brands)
      .where(eq(brands.userId, userId))
      .orderBy(desc(brands.createdAt));
  }

  async getAllBrands(): Promise<Brand[]> {
    return await db
      .select()
      .from(brands)
      .orderBy(desc(brands.createdAt));
  }

  async getBrand(id: string): Promise<Brand | undefined> {
    const [brand] = await db.select().from(brands).where(eq(brands.id, id));
    return brand;
  }

  async createBrand(brand: InsertBrand): Promise<Brand> {
    const [newBrand] = await db.insert(brands).values([brand]).returning();
    return newBrand;
  }

  async updateBrand(id: string, brand: Partial<InsertBrand>): Promise<Brand> {
    const updateData = { ...brand, updatedAt: new Date() };
    const [updatedBrand] = await db
      .update(brands)
      .set(updateData)
      .where(eq(brands.id, id))
      .returning();
    return updatedBrand;
  }

  // Campaign operations
  async getCampaignsByBrandId(brandId: string): Promise<Campaign[]> {
    return await db
      .select()
      .from(campaigns)
      .where(eq(campaigns.brandId, brandId))
      .orderBy(desc(campaigns.createdAt));
  }

  async getCampaign(id: string): Promise<Campaign | undefined> {
    const [campaign] = await db.select().from(campaigns).where(eq(campaigns.id, id));
    return campaign;
  }

  async createCampaign(campaign: InsertCampaign): Promise<Campaign> {
    const [newCampaign] = await db.insert(campaigns).values([campaign]).returning();
    return newCampaign;
  }

  async updateCampaign(id: string, campaign: Partial<InsertCampaign>): Promise<Campaign> {
    const updateData = { ...campaign, updatedAt: new Date() };
    const [updatedCampaign] = await db
      .update(campaigns)
      .set(updateData)
      .where(eq(campaigns.id, id))
      .returning();
    return updatedCampaign;
  }

  // Influencer operations
  async searchInfluencers(filters: {
    category?: string;
    platform?: string;
    minFollowers?: number;
    maxFollowers?: number;
    location?: string;
  }): Promise<Influencer[]> {
    let query = db.select().from(influencers);
    const conditions = [];

    if (filters.category) {
      conditions.push(ilike(influencers.category, `%${filters.category}%`));
    }
    if (filters.platform) {
      conditions.push(eq(influencers.platform, filters.platform));
    }
    if (filters.minFollowers) {
      conditions.push(sql`${influencers.followerCount} >= ${filters.minFollowers}`);
    }
    if (filters.maxFollowers) {
      conditions.push(sql`${influencers.followerCount} <= ${filters.maxFollowers}`);
    }
    if (filters.location) {
      conditions.push(ilike(influencers.location, `%${filters.location}%`));
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions)) as any;
    }

    return await query.orderBy(desc(influencers.followerCount)).limit(20);
  }

  async getInfluencer(id: string): Promise<Influencer | undefined> {
    const [influencer] = await db.select().from(influencers).where(eq(influencers.id, id));
    return influencer;
  }

  async getInfluencerByPlatformId(platformId: string): Promise<Influencer | undefined> {
    const [influencer] = await db.select().from(influencers).where(eq(influencers.platformId, platformId));
    return influencer;
  }

  async createInfluencer(influencer: InsertInfluencer): Promise<Influencer> {
    const [newInfluencer] = await db.insert(influencers).values([influencer]).returning();
    return newInfluencer;
  }

  async updateInfluencer(id: string, influencer: Partial<InsertInfluencer>): Promise<Influencer> {
    const updateData = { ...influencer, updatedAt: new Date() };
    const [updatedInfluencer] = await db
      .update(influencers)
      .set(updateData)
      .where(eq(influencers.id, id))
      .returning();
    return updatedInfluencer;
  }

  // Brand fit score operations
  async getBrandFitScore(brandId: string, influencerId: string): Promise<BrandFitScore | undefined> {
    const [score] = await db
      .select()
      .from(brandFitScores)
      .where(and(eq(brandFitScores.brandId, brandId), eq(brandFitScores.influencerId, influencerId)));
    return score;
  }

  async createBrandFitScore(score: InsertBrandFitScore): Promise<BrandFitScore> {
    const [newScore] = await db.insert(brandFitScores).values([score]).returning();
    return newScore;
  }

  async getBrandFitScoresByBrand(brandId: string): Promise<(BrandFitScore & { influencer: Influencer })[]> {
    return await db
      .select({
        id: brandFitScores.id,
        brandId: brandFitScores.brandId,
        influencerId: brandFitScores.influencerId,
        score: brandFitScores.score,
        analysis: brandFitScores.analysis,
        createdAt: brandFitScores.createdAt,
        influencer: influencers,
      })
      .from(brandFitScores)
      .innerJoin(influencers, eq(brandFitScores.influencerId, influencers.id))
      .where(eq(brandFitScores.brandId, brandId))
      .orderBy(desc(brandFitScores.score));
  }

  // Outreach message operations
  async getMessagesByCampaign(campaignId: string): Promise<(OutreachMessage & { influencer: Influencer })[]> {
    return await db
      .select({
        id: outreachMessages.id,
        campaignId: outreachMessages.campaignId,
        influencerId: outreachMessages.influencerId,
        subject: outreachMessages.subject,
        content: outreachMessages.content,
        personalizedContent: outreachMessages.personalizedContent,
        status: outreachMessages.status,
        sentAt: outreachMessages.sentAt,
        openedAt: outreachMessages.openedAt,
        repliedAt: outreachMessages.repliedAt,
        responseContent: outreachMessages.responseContent,
        emailId: outreachMessages.emailId,
        createdAt: outreachMessages.createdAt,
        updatedAt: outreachMessages.updatedAt,
        influencer: influencers,
      })
      .from(outreachMessages)
      .innerJoin(influencers, eq(outreachMessages.influencerId, influencers.id))
      .where(eq(outreachMessages.campaignId, campaignId))
      .orderBy(desc(outreachMessages.createdAt));
  }

  async createOutreachMessage(message: InsertOutreachMessage): Promise<OutreachMessage> {
    const [newMessage] = await db.insert(outreachMessages).values([message]).returning();
    return newMessage;
  }

  async updateOutreachMessage(id: string, message: Partial<InsertOutreachMessage>): Promise<OutreachMessage> {
    const updateData = { ...message, updatedAt: new Date() };
    const [updatedMessage] = await db
      .update(outreachMessages)
      .set(updateData)
      .where(eq(outreachMessages.id, id))
      .returning();
    return updatedMessage;
  }

  async getCampaignStats(campaignId: string): Promise<{
    sent: number;
    opened: number;
    replied: number;
    confirmed: number;
  }> {
    const messages = await db
      .select()
      .from(outreachMessages)
      .where(eq(outreachMessages.campaignId, campaignId));

    const stats = {
      sent: messages.filter(m => m.status === 'sent' || m.sentAt).length,
      opened: messages.filter(m => m.openedAt).length,
      replied: messages.filter(m => m.repliedAt).length,
      confirmed: messages.filter(m => m.status === 'confirmed').length,
    };

    return stats;
  }
}

export const storage = new DatabaseStorage();
