# ICY - AI-Powered Influencer Outreach Agent

## Overview

ICY is an intelligent influencer marketing platform that automates the process of finding, analyzing, and reaching out to influencers for brand collaborations. The system uses AI to discover relevant influencers across Instagram and YouTube, analyze their content for brand alignment, generate personalized outreach messages, and track campaign performance. Built as a full-stack web application, ICY transforms influencer marketing from manual guesswork into data-driven, automated success.

## Recent Changes (August 2025)

### ✅ Influencer Discovery System - COMPLETE
- YouTube API integration working with real-time data discovery
- Demo influencer system provides backup data during API issues
- Category-based filtering (tech, fitness, travel, food, beauty) 
- Follower count range filtering working perfectly
- Database integration stores discovered influencers automatically

### ✅ AI-Powered Outreach Generation - COMPLETE  
- Gemini 2.0 Flash Lite integration generating personalized messages
- Language detection and localization (e.g., Portuguese for Brazilian channels)
- Content personalization referencing specific influencer posts/content
- Multiple outreach templates with different tones (professional, friendly, creative)
- Robust fallback system with varied template options
- Two endpoints: single outreach + multi-template generation

### ✅ Core Platform Features - COMPLETE
- Professional AI agent themed interface design
- Real-time dashboard with analytics and insights  
- Campaign management system with status tracking
- Brand fit analysis using AI content evaluation
- PostgreSQL database with full schema implementation
- SendGrid email integration for automated campaigns

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript, using Vite for build tooling and development server
- **UI Library**: Radix UI components with shadcn/ui design system for consistent, accessible interface components
- **Styling**: Tailwind CSS with custom ICY-branded color scheme and responsive design patterns
- **State Management**: TanStack Query (React Query) for server state management and data fetching
- **Routing**: Wouter for lightweight client-side routing
- **Component Structure**: Modular component architecture with separate UI components, pages, and business logic components

### Backend Architecture
- **Runtime**: Node.js with Express.js framework for RESTful API endpoints
- **Language**: TypeScript with ES modules for type safety and modern JavaScript features
- **Database Layer**: Drizzle ORM with PostgreSQL (Neon serverless) for type-safe database operations
- **API Design**: RESTful endpoints with proper error handling and request/response validation using Zod schemas

### Database Design
- **ORM**: Drizzle ORM for type-safe database queries and schema management
- **Database**: PostgreSQL with the following core entities:
  - Users: Authentication and profile management
  - Brands: Brand information, target audience, and campaign goals
  - Campaigns: Campaign management with status tracking
  - Influencers: Influencer profiles with platform-specific data
  - Brand Fit Scores: AI-generated compatibility scores between brands and influencers
  - Outreach Messages: Generated and sent messages with tracking data
- **Schema Management**: Database migrations handled through Drizzle Kit

### AI Integration Architecture
- **AI Provider**: Google Gemini AI for content analysis and text generation
- **Brand Fit Analysis**: Multi-factor scoring system analyzing content alignment, audience match, engagement quality, and brand safety
- **Message Generation**: Context-aware personalized outreach message creation based on influencer content and brand voice
- **Content Analysis**: Automated evaluation of influencer posts, captions, and audience demographics

### Authentication & Session Management
- **Session Storage**: PostgreSQL-based session management with configurable expiration
- **User Management**: Basic user profiles with support for email-based identification

## External Dependencies

### Third-Party APIs
- **Google Gemini AI**: Content analysis, brand fit scoring, and personalized message generation
- **Instagram/YouTube APIs**: Influencer discovery and content retrieval (API integration structure in place)
- **SendGrid**: Email delivery service for automated outreach campaigns

### Database & Infrastructure
- **Neon Database**: Serverless PostgreSQL hosting with connection pooling
- **WebSocket Support**: Real-time features using WebSocket connections

### Development & Build Tools
- **Vite**: Frontend build tool with React plugin and development server
- **TypeScript**: Type checking and compilation across frontend and backend
- **Tailwind CSS**: Utility-first CSS framework with PostCSS processing
- **ESBuild**: Backend bundling for production deployments

### UI & Design Dependencies
- **Radix UI**: Accessible, unstyled UI primitives for complex components
- **Lucide React**: Icon library for consistent iconography
- **shadcn/ui**: Pre-built component library built on Radix UI
- **class-variance-authority**: Type-safe CSS class variants
- **Tailwind Merge**: Utility for merging Tailwind CSS classes

### Utility Libraries
- **Zod**: Runtime type validation for API requests and database schemas
- **date-fns**: Date manipulation and formatting
- **clsx**: Conditional CSS class name utility
- **nanoid**: Secure, URL-safe unique ID generation